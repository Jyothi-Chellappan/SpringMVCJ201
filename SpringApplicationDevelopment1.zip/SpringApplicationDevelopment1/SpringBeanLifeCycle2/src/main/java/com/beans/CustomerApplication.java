package com.beans;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class CustomerApplication {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		ctx.register(MyConfiguration.class);
		ctx.refresh();

		Customer mb1 = ctx.getBean(Customer.class);
		System.out.println(mb1.hashCode());
		mb1.setCid(100);
		System.out.println(mb1.getCid());
        
		mb1.setCname("abcd");
		System.out.println(mb1.getCname());

		/*Customer mb2 = ctx.getBean(Customer.class);
		System.out.println(mb2.hashCode());*/	
		ctx.close();
	}
}