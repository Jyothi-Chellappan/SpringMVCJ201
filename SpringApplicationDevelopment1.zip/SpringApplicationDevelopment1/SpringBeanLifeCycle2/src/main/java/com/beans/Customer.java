package com.beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Customer {
  
	int cid;
	String cname;
	
	//constructor
	public Customer() {
		System.out.println("MyBean instance created");
	}
	@PostConstruct
	private void init() {
		System.out.println("Verifying Resources");
	}
	@PreDestroy
	private void shutdown() {
		System.out.println("Shutdown All Resources");
	}
/*
	public void close() {
		System.out.println("Closing All Resources");
	}*/

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}
	
	
}