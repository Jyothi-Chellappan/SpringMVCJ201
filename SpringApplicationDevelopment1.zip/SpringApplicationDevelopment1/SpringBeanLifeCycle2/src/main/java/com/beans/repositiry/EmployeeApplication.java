package com.beans.repositiry;

import java.sql.SQLException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.beans.repositiry.*;

public class EmployeeApplication {
	public static void main(String[] args) throws SQLException {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.beans.repository");
		context.refresh();
		ObjectRepositoryImpl repository = context.getBean(ObjectRepositoryImpl.class);
		// store
		repository.store(new Employee(1, "abc1", "CEO"));
		repository.store(new Employee(2, "abc2", "Editor"));
		repository.store(new Employee(3, "abc3", "CFO"));
		// retrieve
		Employee emp = repository.retrieve(1);
		System.out.println(emp);

		// search
		Employee cfo = repository.search("Meghna");
		System.out.println(cfo);

		// delete
		Employee editor = repository.delete(2);
		System.out.println(editor);

		// close the spring context
		context.close();
	}

}
