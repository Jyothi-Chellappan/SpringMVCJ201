package com.beans.repositiry;

	import java.util.Collection;
	import java.util.HashMap;
	import java.util.Map;
	import org.springframework.stereotype.Repository;
	import com.beans.repositiry.Employee;
	
	@Repository
	public class ObjectRepositoryImpl implements ObjectRepositoryInterface<Employee> {
		
		private Map<Integer, Employee> repository;
		
		public ObjectRepositoryImpl() {
			this.repository = new HashMap();
		}
		
		public void store(Employee emp) {
			repository.put(emp.getId(), emp);
		}
		public Employee retrieve(int id) {
			return repository.get(id);
		}
		public Employee search(String name) {
			Collection<Employee> emps = repository.values();
			for (Employee emp : emps) {
				if (emp.getName().equalsIgnoreCase(name))
					return emp;
			}
			return null;
		}
		public Employee delete(int id) {
			Employee e = repository.get(id);
			this.repository.remove(id);
			return e;
		}
	}
	
