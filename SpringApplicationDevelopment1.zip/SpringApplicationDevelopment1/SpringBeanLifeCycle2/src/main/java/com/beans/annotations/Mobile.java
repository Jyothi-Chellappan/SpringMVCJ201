package com.beans.annotations;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/*
 * @PreDestroy and @PostConstruct are alternative way for bean initMethod and destroyMethod. 
 * 
 */
public class Mobile {
	String mname;
String manufacturer;

public Mobile() {
	
}
	public Mobile(String mname, String manufacturer) {
	super();
	this.mname = mname;
	this.manufacturer = manufacturer;
}

	public String getMname() {
	return mname;
}

public void setMname(String mname) {
	this.mname = mname;
}

public String getManufacturer() {
	return manufacturer;
}

public void setManufacturer(String manufacturer) {
	this.manufacturer = manufacturer;
}

	@PostConstruct
	public void switchOn(){
        System.out.println("Load Android OS");
    }
	
	@PreDestroy
    public void switchOff(){
        System.out.println("Close all applications");
    }
}
