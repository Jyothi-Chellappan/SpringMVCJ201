package com.beans.annotations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MobileConfiguration {
	 @Bean(name = "mob1", initMethod = "switchOn", destroyMethod = "switchOff")
	    Mobile returnMobile(){
	        return new Mobile();
	    }
}

