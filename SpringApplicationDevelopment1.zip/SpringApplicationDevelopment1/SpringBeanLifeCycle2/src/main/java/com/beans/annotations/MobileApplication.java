package com.beans.annotations;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.beans.Customer;
import com.beans.MyConfiguration;
import org.apache.log4j.Logger;

public class MobileApplication {
	   static Logger log = Logger.getLogger(MobileApplication.class.getName());

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		ctx.register(MobileConfiguration.class);
		ctx.refresh();

		Mobile mb1 = ctx.getBean(Mobile.class);
	      log.info("calling setter method");

		mb1.setMname("BlackBerry");
		System.out.println(mb1.getMname());

		mb1.setManufacturer("Apple");
		System.out.println(mb1.getManufacturer());
	      log.info("closing application and closing the context");
		ctx.close();

	}

}
