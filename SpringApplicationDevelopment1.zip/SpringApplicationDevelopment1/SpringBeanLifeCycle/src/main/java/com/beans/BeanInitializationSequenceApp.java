package com.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BeanInitializationSequenceApp {

	public static void main(String[] args) {

		ApplicationContext ac= new ClassPathXmlApplicationContext("CustomerBeans.xml"); 
		BeanInitializationSequence e1=(BeanInitializationSequence)ac.getBean("bean_seq");

	}

}
