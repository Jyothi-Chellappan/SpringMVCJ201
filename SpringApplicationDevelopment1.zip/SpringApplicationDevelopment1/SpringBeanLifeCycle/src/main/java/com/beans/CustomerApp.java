package com.beans;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.beans.Customer;

public class CustomerApp {
	Date d;
		public static void main(String[] args) {
		ApplicationContext ac= new ClassPathXmlApplicationContext("CustomerBeans.xml");
		Customer c1 = (Customer)ac.getBean("cust_one");
		System.out.println(c1.getCname());
	//	c1.destroy();c1.init();
		
	}

}
