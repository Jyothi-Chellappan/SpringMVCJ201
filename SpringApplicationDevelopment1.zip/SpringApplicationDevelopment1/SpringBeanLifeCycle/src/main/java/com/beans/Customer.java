package com.beans;

import java.util.Date;

public class Customer {
	int cid;
	String cname;
	//Date d;

public void init() {
	System.out.println("inside init method");
}

public void destroy() {
	System.out.println("inside destroy method");
}

//constructors
public Customer() {
	
}
public Customer(int cid, String cname) {
	super();
	this.cid = cid;
	this.cname = cname;
}

//setters and getters
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}

}
