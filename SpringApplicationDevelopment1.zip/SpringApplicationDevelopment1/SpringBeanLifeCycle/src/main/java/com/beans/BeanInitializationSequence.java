package com.beans;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.annotation.*;
import org.springframework.stereotype.Component;

@Component
public class BeanInitializationSequence  implements InitializingBean{

	    public BeanInitializationSequence() {  
	       System.out.println("InitSequenceBean: constructor");  
	    }  

	   @PostConstruct  
	    public void postConstruct() {  
	       System.out.println("InitSequenceBean: postConstruct");  
	    }  

	    public void initMethod() {  
	       System.out.println("InitSequenceBean: init-method");  
	    }  

	   // @Override  
	    public void afterPropertiesSet() throws Exception {  
	       System.out.println("InitSequenceBean: afterPropertiesSet");  
	    }
	    
	}  