package injectionbasics;

public class Department {
int did;
String dname;
	
public Department() {
	
}
}
