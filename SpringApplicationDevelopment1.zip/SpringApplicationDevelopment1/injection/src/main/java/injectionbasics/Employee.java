package injectionbasics;

public class Employee {

	int eid;
    String ename;
    
    public Employee() {
    	
    }

}
