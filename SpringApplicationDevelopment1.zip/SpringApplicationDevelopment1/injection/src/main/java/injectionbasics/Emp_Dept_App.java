package injectionbasics;

public class Emp_Dept_App {

public static void main(String[] args) {

	}

}
