package com.beans;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Employee {
	
	//member variables
	int eid;
	String ename;
	List skillset;
	Set phoneno;
	Map emailids;
	Properties application_props;
    //Department dept;
		
	public Map getEmailids() {
		return emailids;
	}
	public Properties getApplication_props() {
		return application_props;
	}
	public void setApplication_props(Properties application_props) {
		this.application_props = application_props;
	}
	public void setEmailids(Map emailids) {
		this.emailids = emailids;
	}
	//constructor
	public Employee() {
	
   }
	//parameterised constructor
	public Employee(int eid, String ename, List skillset, Set phoneno) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.skillset = skillset;
		this.phoneno = phoneno;
	}
	
	
	//generate getters and setters
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public List getSkillset() {
		return skillset;
	}
	public void setSkillset(List skillset) {
		this.skillset = skillset;
	}
	public Set getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(Set phoneno) {
		this.phoneno = phoneno;
	}
	
	
}
