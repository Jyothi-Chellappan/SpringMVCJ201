package com.beans;

public class Department {
	//member variables
	int did;
	String dname;
	
	//no-arg constructor
	
	//setters and getters

}
