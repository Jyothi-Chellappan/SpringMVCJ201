package com.beans;

import java.util.List;

///diff between zero args constructor and default constructor

public class Account {

	List account_holders;

public Account() {
	
}
	
	public Account(List account_holders) {
		super();
		this.account_holders = account_holders;
	}

	public List getAccount_holders() {
		return account_holders;
	}

	public void setAccount_holders(List account_holders) {
		this.account_holders = account_holders;
	}

}
