package com.applications;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.beans.Account;
import com.beans.Employee;
import java.util.*;

public class AccountApplication {

	public static void main(String[] args) {
		
		//An interface is a contract or protocol which should be followed by implemented classes.
		ApplicationContext ac= new ClassPathXmlApplicationContext("Account.xml"); 
				Account a1=(Account)ac.getBean("ac1");
				
				Scanner s = new Scanner(System.in);
					List l = new ArrayList();
								l.add(s.next());
								l.add(s.next());
								a1.setAccount_holders(l);
				System.out.println(a1.getAccount_holders().toString());
	}

}
