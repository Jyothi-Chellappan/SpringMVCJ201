package com.applications;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.beans.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class EmployeeApplication {

	public static void main(String[] args) {

		ApplicationContext ac= new ClassPathXmlApplicationContext("Beans.xml"); 
		Employee e1=(Employee)ac.getBean("emp");
			System.out.println(e1.getEid());
			System.out.println(e1.getEname());
			System.out.println(e1.getPhoneno());
			System.out.println(e1.getSkillset());
			
			Scanner s = new Scanner(System.in);
			List l = new ArrayList();
			l.add(s.next());
			l.add(s.next());
           
		   e1.setSkillset(l);
		   System.out.println(e1.getSkillset());
	}

}
