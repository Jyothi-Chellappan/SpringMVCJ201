package beans;

public class Reservation {

	private String firstname;
	private String lastname;
	private String gender;
	private String[] appointment;
	private String cityfrom;
	private String doctor;
	public Reservation()
	{		
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String[] getAppointment() {
		return appointment;
	}
	public void setAppointment(String[] appointment) {
		this.appointment = appointment;
	}
	
	
	public String getCityfrom() {
		return cityfrom;
	}
	public void setCityfrom(String cityfrom) {
		this.cityfrom = cityfrom;
	}
	public String getDoctor() {
		return doctor;
	}
	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}
		
	
	
	}
