package beans;

//backing bean
public class Login {

	//member variables
	String username;
	String password;
	
	
	public Login() {
		super();
	}
	
	public Login(String u, String p) {
		username=u;
		password=p;
	}
	
	//setters and getters
	
	public String getPassword() {
		return password;
	}
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
		
}
