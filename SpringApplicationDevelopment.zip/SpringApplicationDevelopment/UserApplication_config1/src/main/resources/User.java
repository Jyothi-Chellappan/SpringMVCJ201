
public class User {

	//member variables
	int userid;
	String username;
	String password;
	String email;
	long phoneno;
	//generate getters and setters

	
}
