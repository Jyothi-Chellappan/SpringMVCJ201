package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import dao.UserDaoImpl;
import beans.User;

import dao.UserDaoImpl;
 
@Controller
public class UserLoginController {
 
	@Autowired
	private UserDaoImpl userDao;
	
	@RequestMapping("login")
	public String loginPage() {
		
		return "login";
	}
 
	@RequestMapping(value = "loginsub", method = RequestMethod.POST)
	public ModelAndView userLogin(@RequestParam("userId") int userId, @RequestParam("password") String password) {
 
		ModelAndView mv = new ModelAndView();
 
		User user = new User();
		user.setUserid(userId);
		user.setPassword(password);
 
		String name = userDao.loginUser(user);
 
		if (name != null) {
 
			mv.addObject("msg", "Welcome " + name + ", You have successfully logged in.");
			mv.setViewName("welcome1");
 
		} else {
 
			mv.addObject("msg", "Invalid user id or password.");
			mv.setViewName("login1");
		}
 
		return mv;
 
	}
 
}
