package dao;

import beans.User;

public interface UserDaoInt {

	public int registerUser(User u);
	public String loginUser(User u);
	
}
