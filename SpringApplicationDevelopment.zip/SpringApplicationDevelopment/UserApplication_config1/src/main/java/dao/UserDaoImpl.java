package dao;
   
import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import beans.User;

//User Interface Implementation class
public class UserDaoImpl implements UserDaoInt{
	
	//reference variable of jdbctemplate
	private JdbcTemplate jdbcTemplate;
	
	//creating a constructor
	public UserDaoImpl(DataSource dataSoruce) {
		jdbcTemplate = new JdbcTemplate(dataSoruce);
	}
	
	public int registerUser(User user) {
		//definition
	String sql = "INSERT INTO User VALUES(?,?,?,?,?)";
		try {
			int counter = jdbcTemplate.update(sql, new Object[] { user.getUserid(), user.getUsername(),user.getPassword(),user.getEmail(),user.getPhoneno() });
			return counter;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	public String loginUser(User user) {
		String sql = "SELECT uid FROM User WHERE uid=? AND upassword=?";
		try {
		String userId = jdbcTemplate.queryForObject(sql, new Object[] {
					user.getUserid(),user.getUsername(),user.getPassword(),user.getEmail(),user.getPhoneno() }, String.class);
			return userId;
		} catch (Exception e) {
			return null;
		}
				 
	}

	
}
