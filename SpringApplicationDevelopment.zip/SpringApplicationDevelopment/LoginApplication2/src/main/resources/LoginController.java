import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import beans.Login;
@Controller
public class LoginController {
 
	@RequestMapping(value = "/Login", method = RequestMethod.GET)
  public String init(Model model) {
   // model.addAttribute("msg", "Please Enter Your Login Details");
    return "Login";
  }

 @RequestMapping(value = "Login2", method = RequestMethod.GET)
	  public String init2(Model model) {
	   // model.addAttribute("msg", "Please Enter Your Login Details");
	    return "Login2";
	  }
	/*
 //Annotation that binds a method parameter or method return valueto a named model attribute, exposed to a web view
  @RequestMapping(method = RequestMethod.POST)
  public String submit(Model model, @ModelAttribute("loginBean") Login loginBean) {
    if (loginBean != null && loginBean.getUserName() != null & loginBean.getPassword() != null) {
      if (loginBean.getUserName().equals("ojas") && loginBean.getPassword().equals("ojas123")) {
        model.addAttribute("msg", loginBean.getUserName());
        return "success";
      } else {
        model.addAttribute("error", "Invalid Details");
        return "login";
      }
    } else {
      model.addAttribute("error", "Please enter Details");
      return "login";
    }
  }
  */
}