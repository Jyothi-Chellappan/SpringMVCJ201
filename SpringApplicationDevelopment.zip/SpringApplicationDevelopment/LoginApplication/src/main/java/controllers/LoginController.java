package controllers;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import beans.Login;
@Controller
public class LoginController {
 
   @RequestMapping("login")
  public String init(Model model) {
    model.addAttribute("msg", "Please Enter Your Login Details");
    return "Login";
  }
 //Annotation that binds a method parameter or method return valueto a named model attribute, exposed to a web view
  @RequestMapping(value="submit",method=RequestMethod.POST)
  public String submit(Model model, @ModelAttribute("loginBean") Login lBean,BindingResult br) {
	     String uname=lBean.getUsername();
	  String pwd = lBean.getPassword();
	     
	  System.out.println(uname+","+pwd);
	     // lBean.setUsername(username);
	     System.out.println("inside submit");
	  if (lBean.getUsername() != null && lBean.getPassword() != null) {
		  	System.out.println("inside if block");
		  	System.out.println(lBean.toString());
		  		if (lBean.getUsername().equals("ojas") && lBean.getPassword().equals("ojas123")) {
		  			model.addAttribute("msg", lBean.getUsername());
		  			return "success";
		  		} else {
		  			System.out.println("inside else block");
		  			model.addAttribute("error", "Invalid Details");
    	     		return "errorpage";
		  	}//else block
	  } else {
  	  System.out.println("inside outer else block");

      model.addAttribute("error", "Please enter Details");
      return "errorpage";
    }
  }
}